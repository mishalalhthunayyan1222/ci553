package catalogue;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Currency;
import java.util.Formatter;
import java.util.Locale;

/**
 * A collection of products,
 * used to record the products that are to be wished to be purchased.
 * @author  Mike Smith University of Brighton
 * @version 2.3 (with Discount functionality)
 */
public class Basket extends ArrayList<Product> implements Serializable
{
  private static final long serialVersionUID = 1;
  private int    theOrderNum = 0;          // Order number
  private double discountPercentage = 0.0; // Discount percentage
  
  /**
   * Constructor for a basket which is
   *  used to represent a customer order/ wish list
   */
  public Basket()
  {
    theOrderNum  = 0;
  }

  /**
   * Set the customers unique order number
   * Valid order Numbers 1 .. N
   * @param anOrderNum A unique order number
   */
  public void setOrderNum( int anOrderNum )
  {
    theOrderNum = anOrderNum;
  }

  /**
   * Returns the customers unique order number
   * @return the customers order number
   */
  public int getOrderNum()
  {
    return theOrderNum;
  }

  /**
   * Set the discount percentage for the basket.
   * @param discount The discount percentage (e.g., 10 for 10%)
   */
  public void setDiscountPercentage(double discount)
  {
    discountPercentage = discount;
  }

  /**
   * Calculate the total price after applying the discount.
   * @return The total price after discount.
   */
  public double getTotalWithDiscount()
  {
    double total = getTotalWithoutDiscount();
    return total - (total * discountPercentage / 100);
  }

  /**
   * Calculate the total price without applying the discount.
   * @return The total price without discount.
   */
  public double getTotalWithoutDiscount()
  {
    double total = 0.00;
    for (Product pr : this)
    {
      total += pr.getPrice() * pr.getQuantity();
    }
    return total;
  }

  /**
   * Returns a description of the products in the basket suitable for printing,
   * including the discount applied.
   * @return a string description of the basket products
   */
  public String getDetails()
  {
    Locale uk = Locale.UK;
    StringBuilder sb = new StringBuilder(256);
    Formatter     fr = new Formatter(sb, uk);
    String csign = (Currency.getInstance( uk )).getSymbol();
    
    if (theOrderNum != 0)
      fr.format("Order number: %03d\n", theOrderNum);
      
    if (this.size() > 0)
    {
      double totalWithoutDiscount = 0.00;
      for (Product pr: this)
      {
        int number = pr.getQuantity();
        fr.format("%-7s",       pr.getProductNum());
        fr.format("%-14.14s ",  pr.getDescription());
        fr.format("(%3d) ",     number);
        fr.format("%s%7.2f",    csign, pr.getPrice() * number);
        fr.format("\n");
        totalWithoutDiscount += pr.getPrice() * number;
      }
      fr.format("----------------------------\n");
      fr.format("Subtotal                    %s%7.2f\n", csign, totalWithoutDiscount);
      if (discountPercentage > 0)
      {
        fr.format("Discount (%2.0f%%)          -%s%7.2f\n", 
                  discountPercentage, csign, totalWithoutDiscount * discountPercentage / 100);
      }
      fr.format("Total                       %s%7.2f\n", csign, getTotalWithDiscount());
      fr.close();
    }
    return sb.toString();
  }
}
