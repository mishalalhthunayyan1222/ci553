package clients;

import dbAccess.DBAccess;
import dbAccess.DBAccessFactory;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * LoginView handles user login by authenticating credentials from the database.
 */
public class LoginView {
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton signupButton;
    private JButton loginButton;
    private JLabel messageLabel;
    private Main main;
    private Connection connection;

    public LoginView(Main main) {
        this.main = main;
        initializeDBConnection();
        initializeUI();
    }

    /**
     * Initializes the database connection using the existing DBAccess mechanism.
     */
    private void initializeDBConnection() {
        try {
            DBAccess dbAccess = (new DBAccessFactory()).getNewDBAccess();
            dbAccess.loadDriver();
            connection = DriverManager.getConnection(
                    dbAccess.urlOfDatabase(),
                    dbAccess.username(),
                    dbAccess.password()
            );
        } catch (SQLException e) {
            showErrorAndExit("Database connection failed: " + e.getMessage());
        } catch (Exception e) {
            showErrorAndExit("Database driver loading failed: " + e.getMessage());
        }
    }

    /**
     * Shows an error message and exits the application.
     */
    private void showErrorAndExit(String errorMessage) {
        JOptionPane.showMessageDialog(null, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
        System.exit(1);
    }

    /**
     * Initializes the UI components for the login screen.
     */
    private void initializeUI() {
        frame = new JFrame("Login");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setLayout(null);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(20, 30, 80, 25);
        frame.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(100, 30, 160, 25);
        frame.add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(20, 70, 80, 25);
        frame.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(100, 70, 160, 25);
        frame.add(passwordField);

        loginButton = new JButton("Login");
        loginButton.setBounds(100, 110, 80, 25);
        frame.add(loginButton);
        
        signupButton = new JButton("Sign Up");
        signupButton.setBounds(190, 110, 80, 25);
        frame.add(signupButton);

        signupButton.addActionListener(e -> openSignupView()); // Open SignupView on click
        frame.setVisible(true);
        
        messageLabel = new JLabel();
        messageLabel.setBounds(20, 140, 250, 25);
        frame.add(messageLabel);

        loginButton.addActionListener(e -> handleLogin());
        frame.setVisible(true);
    }

    /**
     * Handles the login button click by authenticating the user.
     */
    private void handleLogin() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        String role = authenticate(username, password);
        if (role != null) {
            dispose();
            main.startClient(role);
        } else {
            messageLabel.setText("Invalid credentials!");
        }
    }
    
    private void openSignupView() {
        frame.dispose(); // Close the login window
        new SignupView(main); // Open the signup view
    }

    /**
     * Authenticates the user by checking the database for valid credentials.
     */
    private String authenticate(String username, String password) {
        String query = "SELECT role FROM Users WHERE username = ? AND password = ?";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);

            try (ResultSet resultSet = preparedStatement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getString("role");
                }
            }
        } catch (SQLException e) {
            messageLabel.setText("Database error: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
    

    /**
     * Closes the login frame.
     */
    public void dispose() {
        frame.dispose();
    }
}
