package clients;

import dbAccess.DBAccess;
import dbAccess.DBAccessFactory;

import javax.swing.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SignupView {
    private JFrame frame;
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JComboBox<String> roleComboBox;
    private JButton signupButton;
    private JLabel messageLabel;
    private Main main;
    private Connection connection;

    public SignupView(Main main) {
        this.main = main;
        initializeDBConnection();
        initializeUI();
    }

    private void initializeDBConnection() {
        try {
            DBAccess dbAccess = (new DBAccessFactory()).getNewDBAccess();
            dbAccess.loadDriver();
            connection = DriverManager.getConnection(
                    dbAccess.urlOfDatabase(),
                    dbAccess.username(),
                    dbAccess.password()
            );
        } catch (SQLException e) {
            showErrorAndExit("Database connection failed: " + e.getMessage());
        } catch (Exception e) {
            showErrorAndExit("Database driver loading failed: " + e.getMessage());
        }
    }

    private void showErrorAndExit(String errorMessage) {
        JOptionPane.showMessageDialog(null, errorMessage, "Error", JOptionPane.ERROR_MESSAGE);
        System.exit(1);
    }

    private void initializeUI() {
        frame = new JFrame("Sign Up");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(300, 250);
        frame.setLayout(null);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setBounds(20, 30, 80, 25);
        frame.add(usernameLabel);

        usernameField = new JTextField();
        usernameField.setBounds(100, 30, 160, 25);
        frame.add(usernameField);

        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(20, 70, 80, 25);
        frame.add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(100, 70, 160, 25);
        frame.add(passwordField);

        JLabel roleLabel = new JLabel("Role:");
        roleLabel.setBounds(20, 110, 80, 25);
        frame.add(roleLabel);

        roleComboBox = new JComboBox<>(new String[]{"customer", "cashier", "packer", "backdoor"});
        roleComboBox.setBounds(100, 110, 160, 25);
        frame.add(roleComboBox);

        signupButton = new JButton("Sign Up");
        signupButton.setBounds(100, 150, 80, 25);
        frame.add(signupButton);

        messageLabel = new JLabel();
        messageLabel.setBounds(20, 180, 250, 25);
        frame.add(messageLabel);

        signupButton.addActionListener(e -> handleSignup());
        frame.setVisible(true);
    }

    private void handleSignup() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String role = (String) roleComboBox.getSelectedItem();

        if (username.isEmpty() || password.isEmpty() || role.isEmpty()) {
            messageLabel.setText("Please fill in all fields.");
            return;
        }

        if (addUserToDatabase(username, password, role)) {
            JOptionPane.showMessageDialog(frame, "Sign Up Successful!", "Success", JOptionPane.INFORMATION_MESSAGE);
            frame.dispose();
            main.showLoginScreen(); // Redirect to login screen
        } else {
            messageLabel.setText("Failed to sign up. Try again.");
        }
    }

    private boolean addUserToDatabase(String username, String password, String role) {
        String query = "INSERT INTO Users (username, password, role) VALUES (?, ?, ?)";
        try (PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            preparedStatement.setString(2, password);
            preparedStatement.setString(3, role);
            int rowsAffected = preparedStatement.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            messageLabel.setText("Database error: " + e.getMessage());
            e.printStackTrace();
        }
        return false;
    }
}
